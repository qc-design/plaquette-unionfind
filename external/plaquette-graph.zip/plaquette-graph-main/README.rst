Plaquette Graph Plugin
#################################

.. header-start-inclusion-marker-do-not-remove

.. image:: https://github.com/qc-design/plaquette-graph/actions/workflows/tests_linux.yml/badge.svg
    :target: https://github.com/qc-design/plaquette-graph/actions/workflows/tests_linux.yml

.. image:: https://github.com/qc-design/plaquette-graph/actions/workflows/docs_linux.yml/badge.svg
    :target: https://qc-design.github.io/plaquette-graph/
|
The `Plaquette-Graph <https://github.com/qc-design/plaquette-graph>`_ plugin extends the `Plaquette <https://github.com/qc-design/plaquette>`_ error correction software, providing a fast graph library written in C++.

.. installation-start-inclusion-marker-do-not-remove

Installation
============

The C++ tests/examples and python bindings can be built independently by

.. code-block:: console

   cmake -Bbuild -G Ninja -DPLAQUETTE_GRAPH_BUILD_TESTS=On -DPLAQUETTE_GRAPH_BUILD_BINDINGS=On
   cmake --build ./build

   
You can run the C++ backend tests with
   
.. code-block:: console

   make test-cpp


You can install just the python interface with (this quietly builds the C++ backend):

.. code-block:: console

   pip install -r requirements.txt
   pip install .


You can run the python frontend tests with
   
.. code-block:: console

   make test-python

To generate the documentation you will need to install graphviz and doxygen. Then run

.. code-block:: console

   pip install -r doc/requirements.txt
   make docs
   firefox ./doc/_build/html/index.html
