Python API
=========================

.. currentmodule:: plaquette_graph
.. automodapi:: plaquette_graph
    :no-heading:
    :include-all-objects:
    :members:
