.. include:: ../README.rst

.. toctree::
   :maxdepth: 1

   Python API <code/__init__>
   C++ API <api/library_root>
