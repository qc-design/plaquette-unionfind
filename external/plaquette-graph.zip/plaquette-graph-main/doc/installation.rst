Installation
#################################

.. include:: ../README.rst
