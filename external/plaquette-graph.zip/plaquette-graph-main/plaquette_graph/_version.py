"""Version information.
   Version number (major.minor.patch[-label])
"""

__version__ = "0.1.0-dev0"
